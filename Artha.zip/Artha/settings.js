global.prefa = ['','!','.',',','ðŸ¤','ðŸ—¿']

global.owner = ['6289656331733']
global.botname = 'CYBERIOR BOT BY ARTHA S.A'
global.baileys1 = require('@whiskeysockets/baileys') 
global.sticker1 = "ARTHA Official"
global.sticker2 = "🌜"